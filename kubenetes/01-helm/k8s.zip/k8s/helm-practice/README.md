# Helm Library Chart 全方位实践案例

> 一个模拟真实公司的场景：**1 个公共库 chart（common）+ 2 个应用 chart（web-app、api-app）**，
> 手把手带你验证 library chart 的"不可安装、可复用、改一处全局生效"三大特性。
>
> 配套理论笔记见上级目录的 `helm.md`。

---

## 0. 案例背景（为什么值得做）

想象你是某公司的运维/开发，公司有 20 个微服务都要部署到 K8s，老板要求：

1. 所有资源名统一格式：`release名-应用名`
2. 所有资源必须带标准标签（运维平台靠标签统计归属）
3. 任何应用不许不配资源配额（防止吃光节点资源）

**笨办法**：每个 chart 里都复制粘贴一份 labels、命名逻辑——20 份拷贝，改规范时改 20 处。
**聪明办法**：把这些逻辑封装进一个 `common` 库 chart，20 个应用都引用它。

本案例用 2 个应用演示这个过程（2 个已经够证明复用价值了）。

## 1. 目录结构

```
helm-practice/
├── common/                    # ⭐ 库 chart（type: library）
│   ├── Chart.yaml             #    声明 type: library
│   └── templates/
│       └── _helpers.tpl       #    只有命名模板，没有任何资源模板
├── web-app/                   # ⭐ 应用 1（type: application）
│   ├── Chart.yaml             #    dependencies 里引用 common
│   ├── values.yaml
│   └── templates/
│       ├── deployment.yaml    #    大量 include 库里的模板
│       └── service.yaml
└── api-app/                   # ⭐ 应用 2，复用同一个 common 库
    ├── Chart.yaml
    ├── values.yaml
    └── templates/
        └── configmap.yaml
```

先打开这几个文件通读一遍，重点看三处：

- `common/Chart.yaml` 的 `type: library`
- `common/templates/_helpers.tpl` 里的 4 个 `define`（这就是库封装的"函数"）
- `web-app/Chart.yaml` 的 `dependencies` 段（这就是"引入 boost"）

## 2. 准备工作

```bash
# 安装 helm（Windows 可用 winget，或去 https://github.com/helm/helm/releases 下载）
winget install Helm.Helm

# 验证
helm version
```

> ✅ 好消息：下面 Step 1~5 全部用 `helm template` 本地渲染验证，**不需要 K8s 集群**。
> 你有虚拟机集群的话，接着做 Step 6 的全链路实战（部署→验证→测试）。

## 3. Step 1：验证"库不能被安装"

```bash
cd helm-practice
helm install test ./common
```

**预期输出（报错是预期的，这正是知识点！）**：

```
Error: INSTALLATION FAILED: library charts are not installable
```

Helm 直接拒绝了你。因为 `type: library` 的 chart 没有"可部署的东西"，它天生就是给别的 chart 引用的。

## 4. Step 2：打包依赖（类比"安装 boost 到项目"）

```bash
helm dependency update ./web-app
```

**预期输出**：

```
Saving 1 charts
Deleting outdated charts
```

执行后观察目录变化：`web-app/charts/common-0.1.0.tgz` 出现了，还多了个 `web-app/Chart.lock`。

> 💡 **重要认知**：这个 tgz 是库的**拷贝**（类比静态链接）。
> 之后改了 common 源码，必须重新执行 `helm dependency update`，否则应用用的还是旧拷贝——这是最常见的坑！

给 api-app 也打包：

```bash
helm dependency update ./api-app
```

## 5. Step 3：渲染 web-app，看库怎么"贴"进结果

```bash
helm template demo ./web-app
```

`helm template` = 本地渲染（不连集群），`demo` 是给这次 release 起的名字。
**预期输出（节选 deployment 部分）**，注意注释指出的三处"库的贡献"：

```yaml
---
# Source: web-app/templates/deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: demo-web-app                # ← 来自 common.name（release名-chart名）
  labels:
    helm.sh/chart: web-app-0.1.0    # ← 以下五行都来自 common.labels
    app.kubernetes.io/name: web-app
    app.kubernetes.io/instance: demo
    app.kubernetes.io/version: "1.0.0"
    app.kubernetes.io/managed-by: Helm
spec:
  replicas: 2
  selector:
    matchLabels:                    # ← 来自 common.selectorLabels
      app.kubernetes.io/name: web-app
      app.kubernetes.io/instance: demo
  template:
    metadata:
      labels:
        app.kubernetes.io/name: web-app
        app.kubernetes.io/instance: demo
    spec:
      containers:
        - name: web-app
          image: "nginx:1.25"
          ports:
            - containerPort: 80
          resources:                # ← 来自 common.resources（values 里没写，用了公司默认值）
            limits:
              cpu: 100m
              memory: 128Mi
            requests:
              cpu: 50m
              memory: 64Mi
```

**试试覆盖配额**（验证"用户值优先于库默认值"）：

```bash
helm template demo ./web-app --set resources.limits.cpu=500m | grep -A 2 "resources:"
```

预期看到 `cpu: 500m`——说明 `common.resources` 里 `with .Values.resources` 的分支逻辑生效了。

## 6. Step 4：渲染 api-app，验证"第二个应用零成本复用"

```bash
helm template demo ./api-app
```

**预期输出**：

```yaml
---
# Source: api-app/templates/configmap.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: demo-api-app-config         # ← common.name 又立功了
  labels:
    helm.sh/chart: api-app-0.1.0    # ← 和 web-app 一模一样的标签规范，
    app.kubernetes.io/name: api-app #   因为用的是同一个库模板！
    app.kubernetes.io/instance: demo
    app.kubernetes.io/version: "2.0.0"
    app.kubernetes.io/managed-by: Helm
data:
  APP_MODE: "production"
```

注意：api-app 自己**一行标签逻辑都没写**，标签规范却自动和 web-app 完全一致——这就是复用。

## 7. Step 5：改一处，两个应用同时生效 ⭐（库的核心价值）

现在老板说："所有资源再加一个标签 `app.kubernetes.io/part-of: demo-system`"。

**改 `common/templates/_helpers.tpl`**，在 `common.labels` 的 define 里加一行：

```
{{- define "common.labels" -}}
helm.sh/chart: {{ .Chart.Name }}-{{ .Chart.Version }}
app.kubernetes.io/name: {{ .Chart.Name }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: demo-system     # ← 新加这一行
{{- end -}}
```

然后**先故意不重新打包依赖**，直接渲染：

```bash
helm template demo ./web-app | grep part-of
# （没有输出！因为用的还是 charts/ 里的旧拷贝——踩坑了）
```

重新打包再看：

```bash
helm dependency update ./web-app
helm dependency update ./api-app
helm template demo ./web-app | grep part-of   # → app.kubernetes.io/part-of: demo-system
helm template demo ./api-app  | grep part-of  # → app.kubernetes.io/part-of: demo-system
```

**两个应用同时生效，而它们自己的代码一行没动。** 如果没有库，这个改动要在 20 个 chart 里改 20 次。

> 做完实验建议把新加的那行删掉、再执行两次 `helm dependency update`，恢复原状。

## 8. Step 6：全链路实战——部署 → 验证 → 测试（真实集群）⭐

> 前提：虚拟机里已有 K8s 集群（kubeadm / minikube / kind 均可）。操作位置二选一：
>
> - **方案 A（Windows 宿主机操作）**：把虚拟机里的 `~/.kube/config` 拷到宿主机 `~/.kube/config`（或 `%USERPROFILE%\.kube\config`），先跑 `kubectl get nodes` 确认能连通集群。
> - **方案 B（直接进虚拟机操作）**：`scp -r helm-practice 用户名@虚拟机IP:~/` 传上去，在虚拟机里装好 helm 和 kubectl 再操作。

### 6.1 部署

```bash
cd helm-practice

# 1. 打包依赖（两份都要，前面 Step 2 做过可跳过）
helm dependency update ./web-app
helm dependency update ./api-app

# 2. 部署到独立命名空间（用完一键清理，不污染集群）
helm install frontend ./web-app -n helm-demo --create-namespace
helm install backend  ./api-app  -n helm-demo

# 3. 确认两个 release 状态
helm list -n helm-demo
```

**预期输出**：

```
NAME      NAMESPACE   REVISION   STATUS     CHART            APP VERSION
backend   helm-demo   1          deployed   api-app-0.1.0    2.0.0
frontend  helm-demo   1          deployed   web-app-0.1.0    1.0.0
```

### 6.2 验证（对账：渲染出的 YAML 是否真的进了集群）

```bash
# 1. 资源全景：Deployment 副本就绪、Pod Running、Service/ConfigMap 存在
kubectl get all,cm -n helm-demo
```

**预期输出**：

```
NAME                                 READY   UP-TO-DATE   AVAILABLE   AGE
deployment.apps/frontend-web-app     2/2     2            2           1m

NAME                                      READY   STATUS    RESTARTS   AGE
pod/frontend-web-app-76d4f9c8d-xxxxx      1/1     Running   0          1m
pod/frontend-web-app-76d4f9c8d-yyyyy      1/1     Running   0          1m

NAME                       TYPE        CLUSTER-IP     PORT(S)   AGE
service/frontend-web-app   ClusterIP    10.96.x.x      80/TCP    1m

NAME                                   DATA   AGE
configmap/backend-api-app-config       1      1m
```

```bash
# 2. 验证库的统一命名规则：资源名 = release名-chart名（frontend-web-app）
#    并重点看 labels 列：helm.sh/chart 和 app.kubernetes.io/* 全部来自 common 库
kubectl get deploy,svc,cm -n helm-demo --show-labels

# 3. 验证 selectorLabels 正确匹配：ENDPOINTS 有地址（若是 <none> 说明 selector 没对上）
kubectl get endpoints frontend-web-app -n helm-demo

# 4. 验证 ConfigMap 内容（api-app 的配置 + 库的统一标签）
kubectl get cm backend-api-app-config -n helm-demo -o yaml

# 5. 验证资源配额兜底：values 没写 → 用了 common 库默认值 100m/128Mi
kubectl get deploy frontend-web-app -n helm-demo -o yaml | grep -A 6 "resources:"
```

### 6.3 测试（业务连通性）

```bash
# 测试 1：端口转发访问 nginx（Ctrl+C 结束转发）
kubectl port-forward -n helm-demo svc/frontend-web-app 8080:80
# 另开一个终端（Windows PowerShell 里用 curl.exe，别用 curl 别名）
curl.exe -I http://localhost:8080
# 预期：HTTP/1.1 200 OK（nginx 欢迎页）

# 测试 2：集群内部 DNS 访问（模拟其他微服务通过 Service 域名调用它）
kubectl run tmp --rm -it --restart=Never --image=curlimages/curl -n helm-demo -- \
  curl -s -o /dev/null -w "%{http_code}\n" http://frontend-web-app.helm-demo.svc.cluster.local
# 预期输出：200

# 测试 3：用库里的统一标签做标签选择器查询（运维平台就是这么发现资源的）
kubectl get all,cm -n helm-demo -l app.kubernetes.io/managed-by=Helm
kubectl get cm -n helm-demo -l app.kubernetes.io/name=api-app
```

### 6.4 进阶：升级与"改库全局生效"的完整闭环

```bash
# 1. 普通升级：扩容副本
helm upgrade frontend ./web-app -n helm-demo --set replicaCount=3
kubectl rollout status deployment/frontend-web-app -n helm-demo   # 等待滚动完成
kubectl get deploy frontend-web-app -n helm-demo                  # READY 3/3

# 2. 改库全局生效：按 Step 5 的方法，给 common/templates/_helpers.tpl
#    的 common.labels 里加一行：app.kubernetes.io/part-of: demo-system
#    然后重新打包并升级两个应用：
helm dependency update ./web-app
helm dependency update ./api-app
helm upgrade frontend ./web-app -n helm-demo
helm upgrade backend  ./api-app -n helm-demo

# 3. 两个应用的资源同时带上新标签——库的价值在真实集群上闭环了
kubectl get deploy,cm -n helm-demo --show-labels | grep part-of
# 预期：frontend 和 backend 的资源都显示 app.kubernetes.io/part-of=demo-system
```

### 6.5 清理

```bash
helm uninstall frontend backend -n helm-demo
kubectl delete ns helm-demo
```

## 9. 常见坑总结

| 坑 | 现象 | 解法 |
|---|---|---|
| 改了库没生效 | 渲染结果还是旧的 | 重新 `helm dependency update`（应用用的是 charts/ 里的拷贝） |
| 忘记打包依赖 | `helm template` 报 `template "common.labels" not defined` | 执行 `helm dependency update` |
| file:// 路径错 | 依赖找不到 | `repository: "file://../common"` 是相对于**应用 chart 目录**的路径 |
| 缩进错乱 | 渲染出的 YAML 层级不对 | `include` 后必须接 `\| nindent N`（贴进来后自己摆正缩进） |
| 模板重名 | 后定义的覆盖先定义的 | 库模板一律 `<库名>.<功能>` 前缀 |

## 10. 自测清单（全部能答上来 = 本主题毕业 ✅）

1. `Chart.yaml` 里 `type` 不写，默认是什么类型？
2. 对 library chart 执行 `helm install` 会怎样？为什么它不能安装？
3. 应用 chart 通过哪两步"接入"一个库？（声明 dependencies → dependency update 打包）
4. `include "common.labels" .` 里的 `.` 是什么意思？（把当前完整上下文传给模板）
5. `| nindent 4` 是干嘛的？不加会怎样？
6. 修改了库之后，为什么必须重新 `helm dependency update`？
7. 库模板为什么要用 `common.` 前缀？

---

**建议节奏**：Step 1~5 本地渲染练习约 20 分钟；然后在虚拟机集群上做 Step 6 全链路（部署→验证→测试）约 20 分钟。
做完把自测清单口头回答一遍，答不上的回 `helm.md` 查对应小节。
