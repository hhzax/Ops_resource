{{/*
====================================================================
common 库 chart：所有模板都用 "common." 前缀命名（防重名的行业约定）
类比：这就是一个"函数库"，每个 define 就是一个封装好的函数
====================================================================
*/}}

{{/*
统一命名规则：release 名 - chart 名
保证全公司所有应用的资源名风格一致。
用法：{{ include "common.name" . }}
*/}}
{{- define "common.name" -}}
{{- printf "%s-%s" .Release.Name .Chart.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
统一标签规范：运维平台靠这些标签识别资源是谁部署的、属于哪个版本。
用法：
  labels:
    {{- include "common.labels" . | nindent 4 }}
*/}}
{{- define "common.labels" -}}
helm.sh/chart: {{ .Chart.Name }}-{{ .Chart.Version }}
app.kubernetes.io/name: {{ .Chart.Name }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{/*
选择标签：必须是 common.labels 的子集，
Deployment 的 matchLabels 和 Service 的 selector 都用它互相关联。
*/}}
{{- define "common.selectorLabels" -}}
app.kubernetes.io/name: {{ .Chart.Name }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{/*
统一资源配额：应用 values.yaml 里写了 resources 就用应用的，
没写就用这里的公司默认值（防止某个应用忘了配额把节点资源吃光）。
*/}}
{{- define "common.resources" -}}
{{- with .Values.resources }}
{{- toYaml . }}
{{- else }}
limits:
  cpu: 100m
  memory: 128Mi
requests:
  cpu: 50m
  memory: 64Mi
{{- end }}
{{- end -}}
