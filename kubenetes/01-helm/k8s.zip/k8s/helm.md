# Helm 学习笔记

> 持续更新中，记录学习 Helm 过程中的知识点。

---

## Chart 的两种类型：application 与 library

### 背景：Chart.yaml 里的 `type` 字段

从 Helm 3 开始（apiVersion: v2），每个 chart 的 `Chart.yaml` 里可以用 `type` 字段声明类型：

```yaml
apiVersion: v2
name: my-app
type: application   # 或者 library；不写的话默认就是 application
version: 0.1.0
```

只有两种合法取值：`application` 和 `library`。

### Application Chart（应用类型）

平时 99% 接触到的**普通 chart**，`helm create` 出来的默认就是这种。

- **可以直接部署**：`helm install` 会在集群里真正创建出 Deployment、Service、ConfigMap 等资源
- 模板目录里放的是"资源模板"——渲染后输出真正的 Kubernetes 资源清单
- 自带 `values.yaml`，用户通过 `--set` 或 `-f` 覆盖默认值

一句话：**它是"成品"，装了就能跑**。

### Library Chart（库类型）

类比：application chart 是"可执行程序"，library chart 是"工具函数库/公共包"。

1. **不能被部署**：`helm install` 一个 library chart 会直接报错
2. **只提供"命名模板"（named templates）给别的 chart 用**，通常写在 `_helpers.tpl` 这类下划线开头的文件里：

   ```yaml
   {{- define "common.labels" -}}
   app.kubernetes.io/name: {{ .Chart.Name }}
   app.kubernetes.io/instance: {{ .Release.Name }}
   {{- end -}}
   ```

3. **通过"依赖"方式被引用**：

   ```yaml
   # my-app 的 Chart.yaml
   dependencies:
     - name: common
       version: 1.0.0
       repository: file://../common
   ```

   然后 `helm dependency update` 打包依赖，在应用 chart 的模板里调用：

   ```yaml
   metadata:
     labels:
       {{- include "common.labels" . | nindent 4 }}
   ```

> 注意：Helm 模板命名是**全局命名空间**，依赖的模板会合并。库里的模板约定用 chart 名做前缀（如 `common.labels`）避免重名。

### 对比总结

|              | Application                | Library                |
| ------------ | -------------------------- | ---------------------- |
| `type` 值    | `application`（默认）       | `library`              |
| 能否安装     | ✅ 可以                    | ❌ 不行                |
| 模板内容     | 资源模板（渲染成 K8s 资源） | 命名模板（工具片段）    |
| 使用方式     | 直接部署                   | 作为依赖被其他 chart 引用 |
| 解决的问题   | 部署应用                   | 代码复用、统一规范      |

### 为什么要设计 Library Chart？

公司有 20 个应用的 chart，都要写统一的 labels、命名规则、探针配置：

- 不用库：同样内容复制 20 份，改一处要改 20 处
- 用库：写一个 `common` 库 chart，20 个应用都依赖它，**改一处，全局生效**

真实案例：Bitnami 的 `bitnami/common`，其几百个 chart 都引用它。

### 类比 C++ 库理解（boost）

library chart 就相当于 boost 这样的第三方库，主程序（application chart）引用它来复用封装好的逻辑：

| C++ 世界                                  | Helm 世界                                                    |
| ----------------------------------------- | ------------------------------------------------------------ |
| boost 这样的第三方库                       | library chart                                                 |
| 项目里声明并引入库（vcpkg/conan 安装）      | `Chart.yaml` 里写 `dependencies` + `helm dependency update`   |
| `#include <boost/xxx.hpp>`                 | `{{ include "common.labels" . }}`                             |
| 调用库里封装好的函数                        | 渲染时展开库里定义好的命名模板                                 |
| 自己的 main 程序（可执行文件）              | application chart                                             |

核心思想一致：**把公共逻辑封装到库里，主程序引用它，实现"写一次、处处复用"**。

两个有助于深入理解的差别：

1. **`include` 更像"宏展开"，而不是函数调用**。C++ 的函数调用是编译链接后的真正调用；Helm 的 `include` 是在渲染时把模板片段做文本替换，直接"贴"进最终输出——更像 C 的 `#define` 宏。所以调用时常配合 `| nindent 4` 调整缩进（贴进来之后要自己摆正位置）。
2. **Helm 模板没有 namespace，靠"约定"防重名**。C++ 有 `boost::xxx` 命名空间；Helm 模板名是全局平铺的，重名会冲突。行业约定：库里的模板一律用 `<库名>.<功能>` 前缀命名（如 `common.labels`），相当于手工模拟命名空间。

另一个与"静态链接"相似之处：`helm dependency update` 会把库 chart 压缩包直接拷进 `charts/` 目录，最终 application chart 是**自包含**的——安装时不需要再去远程仓库找库，类似把库静态编译进了可执行文件。

### 动手练习

1. `helm create my-lib`，`Chart.yaml` 加 `type: library`，删掉 `templates/` 下所有 yaml（只留 `_helpers.tpl`）
2. `helm create my-app`，`Chart.yaml` 加依赖 `file://../my-lib`，模板里 `include` 库里的模板
3. 试着直接 `helm install my-lib` —— 亲眼看一次报错，印象最深

> 🎯 **完整实践案例**：`helm-practice/` 目录下已建好"1 个库 + 2 个应用"的可运行项目，
> 配手把手教程见 [helm-practice/README.md](helm-practice/README.md)（含预期输出、常见坑、自测清单）。

---

## 待补充

- [ ] include 与 template 的区别
- [ ] values 的层叠与覆盖规则
- [ ] subchart（子 chart）机制
- [ ] hook 与升级顺序
