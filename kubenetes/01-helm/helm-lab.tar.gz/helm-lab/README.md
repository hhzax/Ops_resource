# Helm Lab：application 与 library 两种 chart 类型

三个 chart，对应三个实验。需要 Helm 3.x（VM 上先 `helm version` 确认）。

| 目录 | Chart.yaml 里的 type | 演示什么 |
|------|---------------------|----------|
| 01-app-chart  | application（默认） | 普通 chart：直接 install，渲染出真实资源 |
| 02-lib-chart  | library             | 素材库：install 被拒、template 输出为空 |
| 03-use-lib    | application         | 依赖 02-lib-chart，include 它的模板片段 |

## 导入虚拟机

```bash
tar -xzf helm-lab.tar.gz
chmod -R u+rw helm-lab      # 保险动作：YAML 不需要执行权限，可读写即可
cd helm-lab
```

如果文件是经 Windows 共享文件夹拷进去的（而不是用 tar 包），建议再清一次回车符：

```bash
sudo yum install -y dos2unix
find helm-lab -type f -exec dos2unix {} +
```

## 实验 A：application 直接能装

```bash
helm template app1 ./01-app-chart     # 能看到渲染出的 ConfigMap
helm install app1 ./01-app-chart      # 安装成功
kubectl get configmap
helm uninstall app1
```

## 实验 B：library 不能装、也不能渲染

```bash
helm show chart ./02-lib-chart        # 看到 type: library
helm template lib1 ./02-lib-chart     # 输出为空！连 extra.yaml 都不渲染
helm install lib1 ./02-lib-chart      # 报错：Error: INSTALLATION FAILED: library charts are not installable
```

## 实验 C：application 消费 library（精髓）

```bash
cd 03-use-lib
helm template use1 .                  # ① 先报错：no template "lib-chart.configmap" associated（库还没拉下来）
helm dependency update                # ② 生成 charts/lib-chart-0.1.0.tgz 和 Chart.lock
ls charts/
helm template use1 .                  # ③ 现在渲染出两个 ConfigMap：
                                      #    use1-my-cm   （父 chart 自己写的）
                                      #    use1-from-lib（include 库模板生成的）
helm install use1 .
kubectl get configmap
kubectl get cm use1-from-lib -o yaml  # labels 里有 chart-type: library
helm get manifest use1                # install 后查看全量渲染结果
helm uninstall use1
```

## 验证点：两种类型的本质区别

1. `type: application`（不写就是它）：install 时渲染 templates/ 下所有文件（`_` 开头除外）成 K8s 资源。
2. `type: library`：整张 chart 不可安装、不渲染任何资源（连看起来正经的 extra.yaml 也不渲染）；
   它存在的意义是被别的 chart 当"素材库"，通过 `include "库名.片段名"` 复用。
3. 库模板读不到父 chart 的 values —— 想传值必须在 include 时塞进 dict
   （见 03-use-lib/templates/from-lib.yaml 里的 $ctx 传参）。

## 真实世界的例子

Bitnami 的 common chart 就是 library 类型，几乎所有 bitnami 官方 chart 都依赖它复用辅助模板：
https://github.com/bitnami/charts/tree/main/bitnami/common
