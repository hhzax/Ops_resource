{{- define "lib-chart.greeting" -}}
hello from library chart (source: {{ .source | default "unknown" }})
{{- end -}}

{{- define "lib-chart.commonLabels" -}}
managed-by: helm-lab
chart-type: library
{{- end -}}

{{- define "lib-chart.configmap" -}}
apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ .name }}
  labels:
{{ include "lib-chart.commonLabels" . | indent 4 }}
data:
  greeting: {{ .greeting | quote }}
  origin: {{ .origin | quote }}
{{- end -}}
