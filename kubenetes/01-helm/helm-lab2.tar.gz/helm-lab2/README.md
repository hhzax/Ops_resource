# Helm Lab 2：template 渲染实战四连

四个实验对应今天的四个主题。需要 Helm 3.2+（实验 4 的 --create-namespace 需要 3.2 以上）。

| 目录 | 主题 | 核心观察点 |
|---|---|---|
| mini-app + 01-alias | 同一 chart 依赖多次（alias） | 同一份代码渲染两遍，.Chart.Name 变别名，values 按别名分命名空间 |
| 02-scope | 多级 chart 的 values 作用域 | 值只往下流不往上流；global 穿透所有层；爷爷可以隔层传话 |
| 03-schema | values.schema.json 校验 | 渲染之前先验货，配置不合法直接报错 |
| 04-misc | crds/ LICENSE NOTES.txt | CRD 先装、卸载不删；NOTES 渲染后打印；LICENSE 只随包走 |

## 导入虚拟机

```bash
tar -xzf helm-lab2.tar.gz
chmod -R u+rw helm-lab2
cd helm-lab2
```

## 实验 1：同一个 chart 依赖多次（alias）

mini-app 是一个通用小 chart；01-alias 把它依赖了两次，别名 frontend / backend。

```bash
cd 01-alias
helm template a1 .                       # ① 先报错：依赖还没买（charts/ 是空的）
helm dependency update                   # ② 买货
ls charts/
helm template a1 .                       # ③ 三个 ConfigMap：a1-parent-note / a1-fe / a1-be
helm install a1 .
kubectl get cm
helm uninstall a1
```

重点对比 a1-fe 和 a1-be 两个 ConfigMap：

- `origin` 一模一样（都是 mini-app/templates/configmap.yaml）→ 代码只有一份，渲染了两遍
- `chart-name` 分别是 frontend / backend → helm 加载别名实例时把 .Chart.Name 换成了别名
- `message` 各自不同 → values 按"别名"分命名空间（frontend: / backend:），不再按 chart 原名

## 实验 2：多级 chart 的 values 作用域

三层结构：scope-top → charts/mid → charts/leaf。
这次用"直接把子 chart 放进 charts/ 目录"的喂法，不需要 dependency update。

```bash
cd 02-scope
helm template s1 .                       # 一次渲染出 3 个 ConfigMap
helm template s1 . --set mid.leaf.greeting="set-path wins"   # 用 --set 点路径直达孙子
helm install s1 .
kubectl get cm s1-leaf -o yaml
helm uninstall s1
```

对照三个 ConfigMap 的输出，验证四条作用域规则：

1. top 的 greeting 是自己的；mid 拿到的是被覆盖后的 "top -> mid (override)"
   （优先级：外层传进来的 > 子 chart 自己的默认值）
2. leaf 的 greeting 是 "top -> mid -> leaf (grandpa speaks to grandson)" ——
   爷爷隔层传话成功：值按名字逐层下钻合并，top 的 mid.leaf.greeting
   覆盖 mid 的 leaf.greeting，再覆盖 leaf 自己的默认值
3. globalEnv 三层完全一样 —— global: 键自动穿透所有层级
4. 反方向不通：leaf 看不到 top 的 greeting（值只往下流，不往上流）

冷知识（知道就好，别学）：父 chart 模板里其实也能写 .Values.mid.xxx ——
那只是读自己 values 文件里的一段数据，不是"读子 chart 的运行时状态"，官方视为反模式。

## 实验 3：values.schema.json 校验

```bash
cd 03-schema
helm template v1 .                                    # 合法，渲染成功
helm template v1 . --set replicas=20                  # 报错：不能超过 10
helm template v1 . --set name=ab                      # 报错：最少 3 个字符
helm template v1 . --set service.type=HostPort        # 报错：enum 三选一
helm template v1 . --set port=abc                     # 报错：类型必须是 integer
```

要点：校验发生在**渲染之前**——配置不合法根本走不到模板那一步，报错直接指到字段。
schema 只检查你写进 schema 的字段，没写的字段不管。
进阶：想禁止用户乱传字段，在 schema 根上加 "additionalProperties": false（自己试）。

## 实验 4：crds/ 、LICENSE 、NOTES.txt

```bash
cd 04-misc
helm package .                            # 打包
tar -tzf misc-app-0.1.0.tgz               # 看 LICENSE 被装进包里，crds/ 也在
helm install m1 .                         # 看安装完成时打印的 NOTES.txt（default 分支）
kubectl get crd                           # crontabs.stable.example.com 已注册
kubectl get ct                            # 自定义资源实例已创建（短名 ct）
helm install m2 . -n demo --create-namespace   # 换命名空间装第二份，NOTES 走 else 分支
helm uninstall m1
kubectl get ct                            # 实例随 release 一起没了
kubectl get crd                           # CRD 还在！helm uninstall 永远不删 CRD
helm uninstall m2
# 想删 CRD 只能手动：kubectl delete crd crontabs.stable.example.com
```

三个特殊文件的角色：

- crds/：不模板化（写什么发什么，不吃 values）、install 时先于一切资源、uninstall 不删
  —— 类比 C++：先向编译器注册新类型（先声明后使用），声明本身不参与"编译"
- templates/NOTES.txt：也是模板，但渲染结果不发 K8s，只在 install/upgrade 后打印
  —— 类比 main() 结束前的 printf
- LICENSE：不参与任何渲染，只是随包携带，发布到 Artifact Hub 等仓库时会展示
- 另外注意：helm template 的输出里既看不到 CRD 也看不到 NOTES（--include-crds 可带 CRD）

## 四句话带走

1. alias = 同一份 chart 代码实例化两份，各配各的 values，helm 替你把 .Chart.Name 改成别名
2. values 作用域 = 局部变量：子只看自己名字空间 + global；优先级永远是"外层 > 内层默认"
3. values.schema.json = 编译期类型检查，渲染前拦截非法配置
4. crds/ 注册新类型（不渲染、不删除）、NOTES.txt 渲染给人看、LICENSE 打包带走

## 知识点解析（精华版）

### 1. alias：同一份 chart，多个实例

- 是什么：dependencies 里加 alias 字段 = 对同一个 chart 声明多个实例。渲染时 helm 把这份 chart 复制多份，每份用别名当实例名。
- 机制：dependency update 只买一份货（charts/ 里一个 tgz）；渲染时每份实例被改写两处——.Chart.Name 换成别名、.Values 只取父 values 里"别名:"那段。
- 推论：values 命名空间按别名不按原名；origin 相同（代码同源）而 chart-name 不同（身份不同）；条件开关也按别名（condition: frontend.enabled 配 frontend.enabled: false 只关一个实例）。
- 类比：Widget a(cfg1), b(cfg2) —— 类一份、对象两个、构造参数各配各的，alias 就是实例名。

### 2. 多级 chart 的 values 作用域

四条规则：
1. 按名字下钻：父 values 里以子 chart 名字开头的段才传给子（top 的 mid: 段成为 mid 的 .Values）。
2. 外层覆盖内层默认：leaf 的值优先级 = leaf 自己默认 < mid 名下 leaf: 段 < top 的 mid.leaf: 段 < 用户 --set/-f。第一遍学的"默认 < -f < --set"在每层都成立。
3. global 穿透：任何一层的 global: 键自动出现在所有层级的 .Values.global，不用逐层转交；外层覆盖内层。
4. 只往下流不往上流：子看不到父自己的值、看不到兄弟的值。（冷知识：父模板写 .Values.mid.xxx 能跑，但那只是读父自己文件里的数据段，反模式。）
- 为什么这样设计：chart 是独立发布的组件，子 chart 作者不该被父的任意变量污染（封装）；global 是"所有层都要"的东西（环境标识、镜像前缀）的合法通道。
- 类比：作用域链——每层 chart 像一层函数，内层只见自己的参数+实参+全局变量。--set mid.leaf.greeting 的点路径就是这棵 values 树的路径，所以 --set 能直达孙子。

### 3. values.schema.json

- 是什么：chart 根目录的 JSON Schema，声明 values 的"类型签名"。helm 在渲染之前校验（默认值 + -f + --set 合并后的最终结果）。
- 机制：install/upgrade/template/lint 都先校验再渲染；schema 写了什么查什么，没写的字段不管（想全锁死加 "additionalProperties": false）；家族里每张 chart 可各带各的 schema；它不参与渲染，纯守门员。
- 语法五件套：type / enum / minimum-maximum / minLength-pattern / required+properties。
- 类比：函数签名/编译期类型检查——类型不对直接"编译失败"，而不是运行到一半 core dump。
- 怎么用：对外发布的 chart 必带；内部 chart 至少给易错字段加（端口范围、enum、必填）。

### 4. crds/ / LICENSE / NOTES.txt：三个特殊身份文件

- crds/（放 CRD，注册新资源类型）：三铁律——不模板化（写什么发什么，不吃 values）；安装最先（先有类型才能建实例）；uninstall 不删（CRD 集群全局，想删只能 kubectl delete crd 手动）。类比：先 class 声明类型才能创建对象，声明全局注册、不随程序析构。细节：helm template 默认不含 CRD（--include-crds 才带）。
- templates/NOTES.txt：也是模板（能用 .Values/.Release/if），但渲染结果不发 K8s，install/upgrade 结束后打印终端；必须恰好叫 NOTES.txt 且在 templates/ 下；helm template 不显示它。类比：main() 结束前的 printf。
- LICENSE（chart 根目录，可选）：不参与渲染和安装，helm package 打进 tgz，发布到 Artifact Hub 等仓库时展示。类比：随源码发布的 LICENSE——编译器不看，发布必须带。同类角色：README.md（随包展示）、.helmignore（打包忽略清单，同 .gitignore，只影响 helm package）。
